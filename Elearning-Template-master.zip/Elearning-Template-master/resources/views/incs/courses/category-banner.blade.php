<div class="bd-title text-center">
    <div class="bd-tag-share">
        <div class="tag d-flex justify-content-around">
            <a class="primary-btn" href="#">Catégorie</a>
            <a class="primary-btn" href="#">Catégorie</a>
            <a class="primary-btn" href="#">Catégorie</a>
        </div>
    </div>
</div>