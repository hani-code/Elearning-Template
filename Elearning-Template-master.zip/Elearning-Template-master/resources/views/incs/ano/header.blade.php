<nav class="mainmenu mobile-menu">
    <ul>
        <li class="active">
            <a href="#">
                <i class="fas fa-home"></i>
                Accueil
            </a>
        </li>
        <li>
            <a href="#">
                <i class="fas fa-ellipsis-v"></i>
                Suivre un cours
            </a>
        </li>
        <li class="mx-5 px-5">
        </li>
        <li>
            <a href="#">
                <i class="fas fa-chalkboard-teacher"></i>
                Formateur
            </a>
            <ul class="dropdown">
                <li><p class="px-2">Passez à la vue Formateur ici : revenez aux cours que vous enseignez.</p></li>
            </ul>
        </li>
    </ul>
</nav>
<a href="#" class="primary-btn top-btn"><i class="fas fa-user"></i> Connexion</a>